﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica8POE.Forms
{
    public partial class Practica8 : Form
    {
        public Practica8()
        {
            InitializeComponent();
        }
        SqlConnection conexion = new SqlConnection("Data Source=LAPTOP-CHAVEZ;Initial Catalog=EmpresaPOE;Integrated Security=True; TrustServerCertificate=True");

        public void completarTabla()
        {
            string consulta = "SELECT * FROM Empleados";

            SqlDataAdapter da = new SqlDataAdapter(consulta, conexion);

            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridViewDatos.DataSource = dt;
        }
        public void limpiarCampos()
        {
            txtID.Clear();
            txtNombre.Clear();
            txtApellido.Clear();
            txtDireccion.Clear();

            txtID.Focus();
        }
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            conexion.Open();

            string consulta = "INSERT INTO Empleados VALUES" + "(" + txtID.Text + ", '" + txtNombre.Text
                + "','" + txtApellido.Text + "','" + txtDireccion.Text + "')";

            SqlCommand comando = new SqlCommand(consulta, conexion);

            comando.ExecuteNonQuery();
            MessageBox.Show("Registro agregado");

            completarTabla();
            limpiarCampos();

            conexion.Close();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            conexion.Open();

            string consulta = "UPDATE Empleados " + "SET Nombre='" + txtNombre.Text
                + "',Apellido='" + txtApellido.Text + "', Direccion='" + txtDireccion.Text
                + "'WHERE IdEmpleado=" + txtID.Text + "";

            SqlCommand comando = new SqlCommand(consulta, conexion);

            int cantidad;
            cantidad = comando.ExecuteNonQuery();
            if (cantidad > 0)
            {
                MessageBox.Show("Registro actualizado");
            }
            completarTabla();
            limpiarCampos();

            conexion.Close();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            conexion.Open();

            string consulta = "DELETE FROM Empleados WHERE idEmpleado =" + txtID.Text + "";

            SqlCommand comando = new SqlCommand(consulta, conexion);

            comando.ExecuteNonQuery();

            MessageBox.Show("Registro eliminado");

            completarTabla();
            limpiarCampos();
            conexion.Close();
        }

        private void Practica8_Load(object sender, EventArgs e)
        {
            string consulta = "SELECT * FROM Empleados";

            SqlDataAdapter da = new SqlDataAdapter(consulta, conexion);

            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridViewDatos.DataSource = dt;
        }

        private void dataGridViewDatos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = dataGridViewDatos.SelectedCells[0].Value.ToString();
            txtNombre.Text = dataGridViewDatos.SelectedCells[1].Value.ToString();
            txtApellido.Text = dataGridViewDatos.SelectedCells[2].Value.ToString();
            txtDireccion.Text = dataGridViewDatos.SelectedCells[3].Value.ToString();
        }
    }
}