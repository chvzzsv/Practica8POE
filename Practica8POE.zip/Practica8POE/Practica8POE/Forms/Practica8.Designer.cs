﻿namespace Practica8POE.Forms
{
    partial class Practica8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridViewDatos = new DataGridView();
            btnEliminar = new Button();
            btnEditar = new Button();
            btnAgregar = new Button();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            txtApellido = new TextBox();
            txtDireccion = new TextBox();
            txtNombre = new TextBox();
            txtID = new TextBox();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridViewDatos).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewDatos
            // 
            dataGridViewDatos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewDatos.Location = new Point(403, 128);
            dataGridViewDatos.Name = "dataGridViewDatos";
            dataGridViewDatos.ReadOnly = true;
            dataGridViewDatos.RowHeadersWidth = 51;
            dataGridViewDatos.RowTemplate.Height = 29;
            dataGridViewDatos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridViewDatos.Size = new Size(581, 204);
            dataGridViewDatos.TabIndex = 38;
            dataGridViewDatos.CellClick += dataGridViewDatos_CellClick;
            // 
            // btnEliminar
            // 
            btnEliminar.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnEliminar.Location = new Point(325, 373);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(94, 29);
            btnEliminar.TabIndex = 37;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = true;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // btnEditar
            // 
            btnEditar.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnEditar.Location = new Point(196, 373);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(94, 29);
            btnEditar.TabIndex = 36;
            btnEditar.Text = "Editar";
            btnEditar.UseVisualStyleBackColor = true;
            btnEditar.Click += btnEditar_Click;
            // 
            // btnAgregar
            // 
            btnAgregar.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnAgregar.Location = new Point(77, 373);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(94, 29);
            btnAgregar.TabIndex = 35;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = true;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(104, 312);
            label5.Name = "label5";
            label5.Size = new Size(74, 20);
            label5.TabIndex = 34;
            label5.Text = "Dirección";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(104, 255);
            label4.Name = "label4";
            label4.Size = new Size(67, 20);
            label4.TabIndex = 33;
            label4.Text = "Apellido";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(104, 193);
            label3.Name = "label3";
            label3.Size = new Size(67, 20);
            label3.TabIndex = 32;
            label3.Text = "Nombre";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(127, 131);
            label2.Name = "label2";
            label2.Size = new Size(25, 20);
            label2.TabIndex = 31;
            label2.Text = "ID";
            // 
            // txtApellido
            // 
            txtApellido.BorderStyle = BorderStyle.FixedSingle;
            txtApellido.Location = new Point(187, 252);
            txtApellido.Name = "txtApellido";
            txtApellido.Size = new Size(175, 27);
            txtApellido.TabIndex = 30;
            // 
            // txtDireccion
            // 
            txtDireccion.BorderStyle = BorderStyle.FixedSingle;
            txtDireccion.Location = new Point(187, 305);
            txtDireccion.Name = "txtDireccion";
            txtDireccion.Size = new Size(175, 27);
            txtDireccion.TabIndex = 29;
            // 
            // txtNombre
            // 
            txtNombre.BorderStyle = BorderStyle.FixedSingle;
            txtNombre.Location = new Point(187, 186);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(175, 27);
            txtNombre.TabIndex = 28;
            // 
            // txtID
            // 
            txtID.BorderStyle = BorderStyle.FixedSingle;
            txtID.Location = new Point(187, 128);
            txtID.Name = "txtID";
            txtID.Size = new Size(175, 27);
            txtID.TabIndex = 27;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(325, 39);
            label1.Name = "label1";
            label1.Size = new Size(381, 31);
            label1.TabIndex = 26;
            label1.Text = "Mantenimiento de clientes UNIVO";
            // 
            // Practica8
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1018, 450);
            Controls.Add(dataGridViewDatos);
            Controls.Add(btnEliminar);
            Controls.Add(btnEditar);
            Controls.Add(btnAgregar);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtApellido);
            Controls.Add(txtDireccion);
            Controls.Add(txtNombre);
            Controls.Add(txtID);
            Controls.Add(label1);
            Name = "Practica8";
            Text = "Practica8";
            Load += Practica8_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewDatos).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridViewDatos;
        private Button btnEliminar;
        private Button btnEditar;
        private Button btnAgregar;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private TextBox txtApellido;
        private TextBox txtDireccion;
        private TextBox txtNombre;
        private TextBox txtID;
        private Label label1;
    }
}